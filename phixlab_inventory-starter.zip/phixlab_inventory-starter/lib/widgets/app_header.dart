import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:phixlab_inventory/utils/constants.dart';

class AppHeader extends StatelessWidget {
  const AppHeader({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 70,
      padding: const EdgeInsets.all(defaultSpace /2),
      decoration: const BoxDecoration(color: Colors.white, 
      border: Border(bottom: BorderSide(color: Colors.black12, width: .7))),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: defaultSpace),
            child: Row(children: const [Text(
              "BGF",
              style: TextStyle(
                color: primaryColor,
                fontSize: 20,
                fontWeight: FontWeight.w900
              ),
               

              ),
              Text(
                "BGF@",
                style: TextStyle(color: primaryColor, fontSize: 20),
              )

              ],
              ),
              

              
          ),
          Padding(
         padding:const EdgeInsets.symmetric(horizontal: defaultSpace),
         child: Row(
          children: [
            Container(
              height: 25,
              width: 25,
              decoration: const BoxDecoration(
                shape: BoxShape.circle, color: primaryColor),
              child: const Icon(
                Icons.notifications,
                size: 17,
                color: Colors.black54,
              ),

            ),
            const SizedBox(
              width: defaultSpace,
            ),

            Container(
              height: 25,
              width: 25,
              decoration: const BoxDecoration(
                shape: BoxShape.circle, color: primaryColor),
              child: Center(
                child: const Text(
                  "PL", 
                  style: TextStyle(color: Colors.white, fontSize: 12), 
                  ),
              ),
              
              )
              
             ],
         )
          )
        ],
      ),
    );

  }
}

